# Glassmorphism effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/kristen17/pen/VwKbeXL](https://codepen.io/kristen17/pen/VwKbeXL).

